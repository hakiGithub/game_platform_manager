missing SourceMod plugins directory
